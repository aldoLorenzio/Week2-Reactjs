export * from "./movie-list"
export * from "./detail-movie"
