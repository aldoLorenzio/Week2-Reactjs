export function PageNotFound() {
  return (
    <div className="flex justify-center align-middle min-h-[100vh]">
      PAGE NOT FOUND
    </div>
  )
}
