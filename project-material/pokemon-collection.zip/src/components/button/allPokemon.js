export default function AllPokemon() {
  return <div id="btn-all-pokemon">All Pokemon</div>
}
