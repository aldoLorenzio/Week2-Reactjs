import AllPokemon from "../button/allPokemon"

export default function BtnHeader() {
  return (
    <div id="btn-header">
      <AllPokemon />
    </div>
  )
}
